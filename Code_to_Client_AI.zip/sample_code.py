
def calculate_discount(price, percentage):
    return price - (price * percentage / 100)
